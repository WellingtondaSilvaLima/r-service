class Config:
  MONGO_URI='mongodb+srv://wellingtonlimaDevPython:Qazujm%401092@nomesteste.ssgjimc.mongodb.net/'